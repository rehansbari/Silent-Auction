import art
from replit import clear
#HINT: You can call clear() to clear the output in the console.
bidders = {}
print(art.logo)
print("Welcome to the secret auction program.")

def start():
  name = input("What is your name?: ")
  bid = int(input("What's your bid?: $"))
  bidders[name] = bid
  more_bidders = input("Are there any other bidders? Type 'yes' or 'no'. ").lower()

  if more_bidders == "yes":
    clear()
    start()
  else:
    highest_bid = 0
    winner = "" 
    for player in bidders:
      if bidders[player] > highest_bid:
        highest_bid = bidders[player]
        winner = player
    clear()
    print(f"The winner is {winner} with a bid of ${bidders[winner]}")
    
start()